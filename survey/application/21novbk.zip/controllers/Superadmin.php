<?php
class Superadmin extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('adminmodel');

    }
    public function index() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'User Name', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');
           if ($this->form_validation->run() == true) {
                $res = $this->adminmodel->adminlogin($this->input->post('username', TRUE), $this->input->post('password'));
                if ($res) {
                    if($_SESSION['is_superadmin']==1){
                        redirect('admin/manageadmin');
                    }else{
                        redirect('admin/manageuser');
                    }
                } else {
                    $data['message'] = 'Invalid username or password';
                    $this->session->set_flashdata('message', $data);
                    //redirect('superadmin/');
                }
            }else{
                $data['message'] = 'Invalid username or password';
                $this->session->set_flashdata('message', $data);
            }
        }
        $data['body'] = 'login';
        $data['header_title'] = 'Login';
        $this->load->view('admin/template_login', $data);
    }
    public function forgotpassword() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'User Name', 'required');

            if ($this->form_validation->run() == true) {

                $res = $this->adminmodel->checkforgotusername($this->input->post('username'));

                if(count($res)>0){
                    /*
					$adminemail= $res[0]['email'];
                    $to = $adminemail;
                    $subject = "Forgot Password";
                    $txt = "Hi ".$res[0]['admin_fname'].",\r\n\n Your password is :".$res[0]['password'];
                    $headers = "From: noreplay@prismatics.com" . "\r\n";
                    mail($to,$subject,$txt,$headers);
					/**/
					$message='Dear '.$res[0]['admin_fname'].',<br><br>';
					$message.="Your password is ".$res[0]['password']."";					
					$message.="<br><br> Thanks <br> Team Global Library";
					$from_email = "admin@ondai.com";
					$to_email = $res[0]['email'];
					//Load email library
					$this->load->library('email');
					// prepare email
					$this->email
						->from('admin@ondai.com', 'Global Library')
						->to($res[0]['email'])
						->subject('Global Library - Account Verification')
						->message($message)
						->set_mailtype('html');		
					if($this->email->send())
						$this->session->set_flashdata("message","Email sent successfully.");
					else
						$this->session->set_flashdata("message","Error in sending Email.");
                    //$this->session->set_flashdata("message",'Mail sent successfully');
                } else {
                    $this->session->set_flashdata("message",'Mail not sent. Please try again.');
                }
                redirect('superadmin/forgotpassword');
            }
        }
        //$this->load->view('admin/forgotpassword');
        $data['body'] = 'forgotpassword';
        $data['header_title'] = 'Forgor Password';
        $this->load->view('admin/template_login', $data);
    }
}