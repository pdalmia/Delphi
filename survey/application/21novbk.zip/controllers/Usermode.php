<?php
ini_set("error_reporting","E_ALL ^ E_DEPRECATED"); 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Usermode extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->model('usermodel');
    }
	
    public function index() {
        $this->load->library('form_validation');
        $data['error'] = false;
        $data['success'] = true;
        if ($this->input->post('submit')) {
            $email = $this->input->post('email');
            $checkusername = $this->usermodel->checkadminusername($email);
            if (count($checkusername) == 0) {
                $this->admin_fname = $this->input->post('fname');
                $fname = $this->input->post('fname');
                $this->admin_lname = $this->input->post('lname');
                $this->company = $this->input->post('company');
                $this->address1 = $this->input->post('address1');
                $this->address2 = $this->input->post('address2');
                $this->zipcode = $this->input->post('zipcode');
                $this->email = $this->input->post('email');

                $createpassword =  ucfirst(substr($fname, 0, 2));                
                $createpassword = $createpassword."@*".  rand();
                
                $this->password = $createpassword;
                $this->phone = $this->input->post('phone');
                $this->	key_verification = md5($email);
                $this->created_date = date('Y-m-d H:i:s');
                $this->updated_date = date('Y-m-d H:i:s');

                $insert = $this->usermodel->insert_entry('admin_master', $this);
                redirect('/usermode/thankyou');
            } else {
                $data['message'] = 'User with the provided email address already exist. Please enter a new email address.';
                $this->session->set_flashdata('message', $data);
            }
        }
        $data['body'] = 'createuser';
        $data['header_title'] = 'Registration';
        $this->load->view('user/template_user', $data);
    }
    public function thankyou() {
        $data['body'] = 'thankyou';
        $data['header_title'] = 'Thankyou';
        $this->load->view('user/template_user', $data);
    }

    public function verifiefuser(){
        $userkey = $this->uri->segment(4);
        $checkverification=$this->usermodel->checkverificationkey($userkey);
        if(count($checkverification)==0){
            $data['message'] = 'You have wrong authentication.';
            $this->session->set_flashdata('message', $data);
        }else{
            $is_verified=$checkverification[0]['is_verify'];
            $adminid=$checkverification[0]['admin_id'];
            if($is_verified==1){
                $data['message'] = 'Already verified.';
                $this->session->set_flashdata('message', $data);
            }else{
                $dataset=array('is_verify'=>1,'	updated_date'=>date('Y-m-d H:i:s'));
                $update=$this->usermodel->update_entry('admin_master',$dataset,'admin_id',$adminid);
                $password = $checkverification[0]['password'];
                $data['message'] = 'You have verified successfully.<p>Your email would be your username and password is '.$password.', '
                        . 'you can change your password after login.</p></p><p>Please click <a href="'.base_url().'superadmin/">Login</a>';
                $this->session->set_flashdata('message', $data);
            }
        }
        $data['body'] = 'verified';
        $data['header_title'] = 'Verification';
        $this->load->view('user/template_user', $data);
    }
    public function forgotpassword() {
        if ($this->input->post()) {
            $this->form_validation->set_rules('username', 'User Name', 'required');
            if ($this->form_validation->run() == true) {
                $res = $this->adminmodel->checkusername($this->input->post('username'));
                if (count($res) > 0) {
                    $adminemail = $res[0]['email'];
                    $to = $adminemail;
                    $subject = "Forgot Password";
                    $txt = "Your password :" . $res[0]['email'];
                    $headers = "From: noreplay@prismatics.com" . "\r\n";
                    mail($to, $subject, $txt, $headers);
                    echo 'success';
                } else {
                    echo 'unsuccess';
                }
            }
            die;
        }
        $data['header_title'] = 'Forgor Password';
        $this->load->view('forgotpassword');
    }

} 