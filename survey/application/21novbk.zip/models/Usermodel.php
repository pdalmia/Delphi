<?php

class Usermodel extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->helper('cache');
    }

    function checkadminusername($username) {
        $query=$this->db->get_where('admin_master',array('email='=>$username,'is_delete='=>0));
        return $query->result_array();
    }
    function insert_entry($table,$data){
        $this->db->insert($table,$data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }
    function checkverificationkey($key) {
        $query=$this->db->get_where('admin_master',array('key_verification='=>$key));
        return $query->result_array();
    }
    function update_entry($table,$data,$filed,$fieldvalue){
        $this->db->update($table,$data,array($filed=>$fieldvalue));
    }
}

?>