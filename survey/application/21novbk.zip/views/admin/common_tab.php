<?php
if($body=='editsurvey'){
    $surveycust='active';$questcust='';$preposcust='';$templatecust='';$usercust='';
}elseif($body=='managequestiongroup' || $body=='createquestiongroup' || $body=='editquestiongroup' || $body=='managequestion' || $body=='createquestion' || $body=='editquestion') {
    $surveycust='';$questcust='active';$preposcust='';$templatecust='';$usercust='';
}elseif($body=='manageproposition' || $body=='createproposition' || $body=='editproposition') {
    $surveycust='';$questcust='';$preposcust='active';$templatecust='';$usercust='';
}elseif($body=='managetemplate' || $body=='createtemplate' || $body=='edittemplate') {
    $surveycust='';$questcust='';$preposcust='';$templatecust='active';$usercust='';
}else{
    $surveycust='';$questcust='';$preposcust='';$templatecust='';$usercust='active';
}
//$survey_id=base64_encode($survey_id);
?>
<ul class="nav nav-tabs">
    <li class="<?php echo $surveycust;?>"><a href="<?php echo base_url(); ?>admin/editsurvey/survey_id/<?php echo $survey_id; ?>">Survey</a></li>
    <li class="<?php echo $questcust;?>"><a href="<?php echo base_url(); ?>admin/managequestiongroup/survey_id/<?php echo $survey_id; ?>">Question</a></li>
    <li class="<?php echo $preposcust;?>"><a href="<?php echo base_url(); ?>admin/manageproposition/survey_id/<?php echo $survey_id; ?>">Preposition</a></li>
    <li class="<?php echo $templatecust;?>"><a href="<?php echo base_url(); ?>admin/managetemplate/survey_id/<?php echo $survey_id; ?>">Templates</a></li>
    <li class="<?php echo $usercust;?>"><a href="<?php echo base_url(); ?>admin/managesurveyuser/survey_id/<?php echo $survey_id; ?>">Users</a></li>
</ul>