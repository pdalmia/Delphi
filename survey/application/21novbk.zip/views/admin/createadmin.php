<div class="page-content-wrapper">
    <div class="page-content">
        <!-- END SAMPLE PORTLET CONFIGURATION MODAL FORM-->
        <!-- BEGIN PAGE HEADER-->
        <h3 class="page-title"> Admin Management </h3>
        <?php
        $mess = $this->session->flashdata('message');
        if ($mess!='') { ?>
            <div class="alert-success2 alert">
                <?php echo $mess['message']; ?>
            </div>
        <?php }?>
        <!-- BEGIN PAGE CONTENT-->
        <div class="row">
            <div class="col-md-12">
                <div class="portlet box blue-hoki" id="form_wizard_1">
                    <div class="portlet-title">
                        <div class="caption"> <i class="fa fa-gift"></i> Admin Wizard</div>
                        <div class="tools hidden-xs"> <a href="javascript:;" class="collapse"> </a> <a href="#portlet-config" data-toggle="modal" class="config"> </a> <a href="javascript:;" class="reload"> </a> <a href="javascript:;" class="remove"> </a> </div>
                    </div>
                    <div class="portlet-body form">
                        <form action="" class="form-horizontal" id="submit_form" method="POST" onsubmit="return adminuserValidate();">
                            <div class="form-wizard">
                                <div class="form-body">
                                     <div class="tab-content">
                                        <div class="alert alert-danger display-none">
                                            <button class="close" data-dismiss="alert"></button>
                                            You have some form errors. Please check below. </div>
                                        <div class="alert alert-success display-none">
                                            <button class="close" data-dismiss="alert"></button>
                                            Your form validation is successful! </div>
                                        <div class="tab-pane active" id="tab1">
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">First Name:<em>*</em></label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" placeholder="Name" maxlength="150" value="<?php echo @$_REQUEST['fname'];?>" id="fname" name="fname">
                                                    <div class="error" style="display:none;" id="ERROR_fname"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Last Name:<em>*</em></label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" placeholder="Name" maxlength="150" value="<?php echo @$_REQUEST['lname'];?>" id="lname" name="lname">
                                                    <div class="error" style="display:none;" id="ERROR_lname"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Organisation:</label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" name="company" maxlength="150" id="company" value="<?php echo @$_REQUEST['company'];?>" placeholder="Organisation">
                                                    <div class="error" style="display:none;" id="ERROR_company"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Address1:</label>
                                                <div class="col-md-4">
                                                    <textarea class="form-control" name="address1" id="address1" maxlength="500" rows="3"><?php echo @$_REQUEST['address1'];?></textarea>
                                                    <div class="error" style="display:none;" id="ERROR_address1"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Address2:</label>
                                                <div class="col-md-4">
                                                    <textarea class="form-control" name="address2" id="address2" maxlength="500" rows="3"><?php echo @$_REQUEST['address2'];?></textarea>
                                                    <div class="error" style="display:none;" id="ERROR_address2"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Postcode/Zip:</label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" placeholder="Postcode/Zip" maxlength="150" value="<?php echo @$_REQUEST['zipcode'];?>" id="zipcode" name="zipcode">
                                                    <div class="error" style="display:none;" id="ERROR_zipcode"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Email:<em>*</em></label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control" name="email" id="email" value="<?php echo @$_REQUEST['email'];?>" placeholder="Email Address">
                                                    <div class="error" style="display:none;" id="ERROR_email"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Password:</label>
                                                <div class="col-md-4">
                                                    <input name="password" type="password" class="form-control" maxlength="150" id="password" value="<?php echo @$_REQUEST['password'];?>" placeholder="Password">
                                                    <div class="error" style="display:none;" id="ERROR_password"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label">Phone:</label>
                                                <div class="col-md-4">
                                                    <input type="text" class="form-control numeric_value" name="phone" id="phone" value="<?php echo @$_REQUEST['phone'];?>" maxlength="19" placeholder="Phone No">
                                                    <div class="error" style="display:none;" id="ERROR_phone"></div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-2 control-label"></label>
                                                <div class="col-md-4">
                                                    <button type="submit" name="submit" value="submit" class="btn green button-submit"> Submit <i class="m-icon-swapright m-icon-white"></i> </button>
                                                    <button type="button" name="Back" value="Back" class="btn button-submit" onclick="return history.back();"> Back <i class="m-icon-swapright m-icon-white"></i> </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT-->
    </div>
</div>