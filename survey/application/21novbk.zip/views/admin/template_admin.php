<?php
$this->load->view('admin/header');
//$this->load->view('admin/top');
$this->load->view('admin/'.$body);
$this->load->view('admin/footer');
?>