<?php
$this->load->view('admin/header_login');
$this->load->view('admin/'.$body);
$this->load->view('admin/footer');
?>