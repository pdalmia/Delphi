<?php
$this->load->view('user/header');
//$this->load->view('admin/top');
$this->load->view('user/'.$body);
$this->load->view('user/footer');
?>